"""Mechanical synthetic-source checks; no candidate/verifier imports or execution."""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

SPEC = importlib.util.spec_from_file_location("ng_report_renderer", Path(__file__).with_name("render_report.py"))
renderer = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(renderer)


class RendererTests(unittest.TestCase):
    def fixture(self, root):
        # All counts are deliberately synthetic; these are not research observations.
        marker = root / "synthetic-input.txt"
        marker.write_text("synthetic renderer input\n")
        arms = [{"kind": kind, "alpha_integer": alpha, "beta_integer": beta,
                 "complete": False, "group_count": 1, "ordering_pass_groups": 0,
                 "actual_recovery_pass_groups": 0, "undefined_count": 1,
                 "truth_mismatch_count": 2, "finite_template_pass": False}
                for kind, alpha, beta in renderer.ARM_KEYS]
        report = {"schema": "classical.ecdlp.nongeneric-screen-verification/v1",
                  "scope": "complete_fixed_fixture", "protocol_sha256": [renderer.PLAN],
                  "source_fingerprint": [renderer.SOURCE], "integrity_pass": False,
                  "errors": [{"error": "synthetic incomplete example"}],
                  "record_count": 3, "actual_recovery_record_count": 1,
                  "arm_reports": arms, "group_reports": [], "actual_recovery_reports": [],
                  "validator_positive_controls": []}
        path = root / "verification/report.json"
        path.parent.mkdir()
        path.write_text(json.dumps(report))
        census = {"schema": "classical.ecdlp.nongeneric-screen.summary-census/v1",
                  "experiment_id": renderer.EXPERIMENT, "run_id": renderer.RUN,
                  "measurement_started": True, "protocol_sha256": renderer.PROTOCOL,
                  "screen_plan_sha256": renderer.PLAN, "source_fingerprint": renderer.SOURCE,
                  "verification_report_sha256": renderer.sha(path),
                  "observed_record_count": 3, "observed_recovery_group_records": 1,
                  "input_bindings": {str(marker): renderer.sha(marker)},
                  "compute_summary": {"schema": "nongeneric.compute-summary/v1",
                                      "measurement_started": True, "experiment_id": renderer.EXPERIMENT,
                                      "protocol_sha256": renderer.PLAN, "source_fingerprint": renderer.SOURCE}}
        (root / "summary-census.json").write_text(json.dumps(census))
        return report, census

    def test_integrity_failure_and_all_48_failed_or_undefined_arms_remain_visible(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.fixture(root)
            report, _, arms, _ = renderer.load_inputs(root)
            self.assertIs(report["integrity_pass"], False)
            self.assertEqual(len(arms), 48)
            self.assertEqual(sum(row["kind"] == "candidate" for row in arms), 40)
            self.assertEqual(sum(row["undefined_count"] for row in arms), 48)
            self.assertEqual(len(renderer.markdown_table(arms)), 50)
            self.assertTrue(all("fail" in row for row in renderer.markdown_table(arms)[2:]))

    def test_changed_bound_input_or_software_subset_cannot_be_published_as_actual(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            report, census = self.fixture(root)
            (root / "synthetic-input.txt").write_text("changed bytes\n")
            with self.assertRaisesRegex(ValueError, "bound input changed"):
                renderer.load_inputs(root)
            report["scope"] = "software_subset_not_scientific_screen"
            path = root / "verification/report.json"
            path.write_text(json.dumps(report))
            census["verification_report_sha256"] = renderer.sha(path)
            (root / "summary-census.json").write_text(json.dumps(census))
            with self.assertRaisesRegex(ValueError, "actual complete-scope"):
                renderer.load_inputs(root)

    def test_global_and_recovery_operation_families_are_separate_without_prices(self):
        compute = {"planning_cost": {"coordinate_enumeration": {"point_check": 17},
                                     "plan_description_pass": {"coordinate_enumeration": {"point_check": 17}}},
                   "operation_counts": {"setup": {"field_mul": 5}, "evaluate": {"field_mul": 8}},
                   "recovery_operation_counts": {"gate": {"point_add": 3}, "fresh_setup": {},
                                                 "evaluate": {}, "reduction": {}}}
        rows = dict(renderer.counter_rows({"validator_counts": {"oracle_and_laws": {"group_add": 23}}}, compute))
        self.assertEqual(rows["producer.planning_cost.coordinate_enumeration.point_check"], 17)
        self.assertEqual(rows["producer.planning_cost.plan_description_pass.coordinate_enumeration.point_check"], 17)
        self.assertEqual(rows["producer.grid.setup.field_mul"], 5)
        self.assertEqual(rows["producer.recovery.gate.point_add"], 3)
        self.assertEqual(rows["validator.oracle_and_laws.group_add"], 23)
        self.assertEqual(len(rows), 6)


if __name__ == "__main__":
    unittest.main()
