#!/usr/bin/env python3
"""One-shot verification/export of sealed NG data; never run a constructor.

The frozen independent verifier consumes the exact screen-plan bytes, while the
generic export binds the separate official frozen experiment protocol. One arm
row is the full finite fixture, not one of its 120 repeated base/view groups.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import sys
import time

PREFIX = "harness/classical_ecdlp_nongeneric_screen"
SOURCE_C = "2311b9d30c346fca4f06ef1ce25af78d92f4be7d"
OFFICIAL_SHA = "31d6425d88c3217ddab47fe3fbc295a6ec6b0af3513942f0fc2a9156ccea7d3d"
OFFICIAL_FILE_SHA = "edfbec02c5e048376f97d331cd1a0d8eda9dff5a559febf4705c706626e5547c"
PLAN_SHA = "2152978af8dfe1f86b6225d14f0e587b030339a3fe6e948fdc7480a480d2bed3"
MANIFEST_SHA = "b54ed025f45355dbc73f38cc08c19b5b08a44ca4c43b16318800d023755ef5fd"
PINS = {"compute.py":"209ba57e45ff1c08d459f9e54b8935c6a9b3f32f1a5d6b3a8358238aaa4c6c20",
        "constructor.py":"31e58db07649df4e61ec2cbcaa1969789bc2c7f229c21f8555daaaaad8fdc451",
        "controller.py":"0a424370e61f244a2e679fd2766a95547b8a3f46a29843e2fd3152943be07338",
        "curve.py":"6ce0b50fcc78287de7091c36383b5ccefb5dbe208ba3d1ab1c80b1ddbc326400",
        "driver.py":"4be8821e7a5b9f0864fd1959dc958f342163335c29286be7a776b8334e9f0095",
        "verify.py":"2d7a603e8ff76b5985dcb3ad4ca90513c5299e4b903e0c5525918954342be6c6"}


def need(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            h.update(block)
    return h.hexdigest()


def read(path):
    def unique(pairs):
        out = {}
        for key, value in pairs:
            need(key not in out, "duplicate JSON key")
            out[key] = value
        return out
    return json.loads(Path(path).read_text(), object_pairs_hook=unique)


def write(path, value):
    with Path(path).open("x") as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write("\n")


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)


def member(root, relative):
    rel = PurePosixPath(relative)
    need(not rel.is_absolute() and ".." not in rel.parts and str(rel) == relative, "unsafe archive member")
    path = root / relative
    need(not path.is_symlink() and path.resolve().is_relative_to(root.resolve()), "archive member escapes tree")
    return path


def locate_raw(path):
    path = Path(path).resolve()
    candidates = [path / name for name in (".", "raw", "tree/raw", "collected/tree/raw", "modal/collected/tree/raw")]
    found = {p.resolve() for p in candidates if (p / "records.jsonl").is_file() or (p / "failure.json").is_file()}
    need(len(found) == 1, "expected one bounded sealed raw directory")
    return found.pop()


def invoke(label, argv, out, repo):
    start = time.time()
    write(out / (label + ".invocation.json"), {"argv": argv, "cwd": str(repo), "attempts": 1,
          "automatic_retry": False, "started_unix_seconds": start})
    stdout, stderr = out / (label + ".stdout.txt"), out / (label + ".stderr.txt")
    with stdout.open("xb") as so, stderr.open("xb") as se:
        proc = subprocess.run(argv, cwd=repo, stdout=so, stderr=se, check=False)
    result = {"argv": argv, "returncode": proc.returncode, "attempts": 1, "automatic_retry": False,
              "started_unix_seconds": start, "finished_unix_seconds": time.time(),
              "stdout_sha256": sha(stdout), "stderr_sha256": sha(stderr)}
    write(out / (label + ".result.json"), result)
    return result


def load_jsonl(path):
    rows, errors = [], []
    if not path.is_file():
        return rows, [{"error": "missing_stream", "path": str(path)}]
    with path.open("rb") as stream:
        for line, data in enumerate(stream, 1):
            try:
                need(bool(data.strip()), "empty JSONL line")
                item = json.loads(data)
                need(isinstance(item, dict), "non-object JSONL row")
                rows.append(item)
            except (ValueError, UnicodeError) as error:
                errors.append({"path": str(path), "line": line, "error": type(error).__name__, "bytes_sha256": hashlib.sha256(data).hexdigest()})
    return rows, errors


def add_counts(total, counts):
    need(isinstance(counts, dict), "counter family object required")
    for name, value in counts.items():
        need(isinstance(name, str) and type(value) is int and value >= 0, "nonnegative integer counter required")
        total[name] += value


def aggregate_cases(records, recoveries, mapping):
    """Aggregate retained phases only, without copying setup or gate costs."""
    result = {}
    seen_cases, seen_recovery, findings = set(), set(), []
    for row in records:
        try:
            need(row.get("schema") == "nongeneric.case/v1", "wrong case schema")
            arm = row["arm"]["id"]
            need(arm in mapping, "unplanned arm")
            need(row["case_id"] not in seen_cases, "duplicate case ID")
            seen_cases.add(row["case_id"])
            slot = result.setdefault(arm, {"cases": 0, "statuses": Counter(), "groups": defaultdict(list),
                "setup": Counter(), "evaluate": Counter(), "setup_charge_groups": Counter(),
                "recovery": {p: Counter() for p in ("gate", "fresh_setup", "evaluate", "reduction")},
                "recovery_groups": 0, "fresh_predicate_evaluations": 0, "fresh_recovered_targets": 0,
                "recovery_gate_pass_groups": 0})
            slot["cases"] += 1
            slot["groups"][row["group_id"]].append(row["case_id"])
            slot["statuses"][row["result"]["status"] + ":" + str(row["result"].get("reason"))] += 1
            need(type(row["setup_charged"]) is bool, "missing/invalid setup charge marker")
            if row["setup_charged"]:
                slot["setup_charge_groups"][row["group_id"]] += 1
                add_counts(slot["setup"], row["counters"]["setup"])
            add_counts(slot["evaluate"], row["counters"]["evaluate"])
        except (ValueError, KeyError, TypeError) as error:
            findings.append({"stream": "records", "case_id": row.get("case_id"), "error": str(error)})
    for row in recoveries:
        try:
            need(row.get("schema") == "nongeneric.recovery-group/v1", "wrong recovery schema")
            arm = row["arm"]["id"]
            need(arm in result and row["group_id"] not in seen_recovery, "unplanned/duplicate recovery group")
            seen_recovery.add(row["group_id"])
            slot = result[arm]
            slot["recovery_groups"] += 1
            for phase in slot["recovery"]:
                add_counts(slot["recovery"][phase], row["counters"][phase])
            slot["fresh_predicate_evaluations"] += row["predicate_evaluations"]
            slot["fresh_recovered_targets"] += sum(x["result"]["status"] == "RECOVERED" for x in row["recoveries"])
            slot["recovery_gate_pass_groups"] += row["gate"]["pass"] is True
        except (ValueError, KeyError, TypeError) as error:
            findings.append({"stream": "recovery", "group_id": row.get("group_id"), "error": str(error)})
    for arm, slot in result.items():
        slot["complete"] = (slot["cases"] == 1560 and len(slot["groups"]) == 120 and
            all(len(ids) == 13 for ids in slot["groups"].values()) and
            set(slot["setup_charge_groups"]) == set(slot["groups"]) and
            all(n == 1 for n in slot["setup_charge_groups"].values()) and slot["recovery_groups"] == 120)
    return result, findings


def raw_arm_report(row):
    if row["kind"] == "wrong_root":
        return "wrong_root:anchored_power_root"
    return f"{row['kind']}:a{row['alpha_integer']}:b{row['beta_integer']}"


def file_entry(path, base, kind="raw"):
    path = Path(path).resolve()
    return {"path": os.path.relpath(path, base), "bytes": path.stat().st_size, "sha256": sha(path), "kind": kind}


def build_export(ep, protocol, protocol_path, raw, modal, out, export_id, report_path, census_path,
                 aggregates, report, provider, sealed_files, findings):
    export = ep.export_skeleton(protocol, os.path.relpath(protocol_path, out), "modal", export_id)
    export["producer"] = {"runtime": "codex_cli", "model": None, "session": None, "role": "executor"}
    export["source"] = {"repo": protocol["repository"], "commit": SOURCE_C, "dirty": None}
    export["arms"] = [{"id": a["id"], "role": a["role"], "commit": SOURCE_C, "binary_sha256": None} for a in protocol["arms"]]
    provider_path = modal / "provider-context.json"
    export["host"]["path"] = os.path.relpath(provider_path, out)
    export["host"]["sha256"] = sha(provider_path)
    valid = bool(report and report.get("integrity_pass") is True and report.get("scope") == "complete_fixed_fixture" and not findings)
    arm_reports = {raw_arm_report(a): a for a in (report or {}).get("arm_reports", [])}
    mapping = protocol["extensions"]["nongeneric_screen"]["raw_to_protocol_arm_id"]
    rows = []
    for arm in protocol["arms"]:
        raw_id = arm["parameters"]["raw_arm_id"]
        if raw_id not in aggregates:
            continue  # No fabricated observation for an unobserved arm.
        data, assessment = aggregates[raw_id], arm_reports.get(raw_id)
        complete = data["complete"] and bool(assessment and assessment["complete"])
        counts = {"observed_case_count": data["cases"]}
        if valid and complete:
            counts.update(complete_case_count=data["cases"],
                          finite_template_pass_count=int(arm["role"] == "candidate" and assessment["finite_template_pass"]),
                          undefined_count=assessment["undefined_count"], truth_mismatch_count=assessment["truth_mismatch_count"],
                          conditional_recovery_verified_count=data["fresh_recovered_targets"])
        vectors = {"constructor_setup": dict(data["setup"]), "constructor_evaluate": dict(data["evaluate"]),
                   "fresh_recovery": {k: dict(v) for k, v in data["recovery"].items()}}
        counts["operation_cost_vector"] = canonical(vectors)
        counters = {"retained_groups": len(data["groups"]), "retained_recovery_groups": data["recovery_groups"],
                    "fresh_predicate_evaluations": data["fresh_predicate_evaluations"],
                    "recovery_gate_pass_groups": data["recovery_gate_pass_groups"], "native_counter_execution_replayed": "false"}
        counters.update({phase + "." + family: str(value) if value > 2**53-1 else value
                         for phase, vector in (("constructor_setup", data["setup"]), ("constructor_evaluate", data["evaluate"]),
                             *(("recovery_" + k, v) for k, v in data["recovery"].items())) for family, value in vector.items()})
        # A completed finite measurement may validly contain wrong/undefined bits.
        row = ep.run_row(run_id="RUN-ECDLP-a11661." + arm["id"], arm=arm["id"], instance_id="0", seed=None,
            replicate=0, status="succeeded" if complete else "infra_error", attempts=1, resumed=0,
            measurements={"counted": counts, "wall_valid": False, "counters": counters},
            verification={"status": "verified" if valid and complete else "error" if report else "not_run",
                          "verifier": "frozen independent verify.py" if report else None},
            exclusion={"excluded": not (valid and complete), "rule": "incomplete or invalid retained finite screen" if not (valid and complete) else None},
            worker=provider["sandbox_id"], backend_ref=provider["sandbox_id"] + ":" + raw_id)
        rows.append(row)
    export["runs"], export["flow"] = rows, ep.compute_flow(rows)
    files = [file_entry(p, out, "receipt" if p.suffix == ".json" else "raw") for p in sealed_files]
    files += [file_entry(p, out, "receipt") for p in (protocol_path, modal / "compute-plan.json", modal / "source-manifest.json", provider_path, census_path)]
    outputs = []
    if report_path.is_file():
        outputs = [file_entry(report_path, out, "analysis")]
        files.extend(outputs)
    export["files"] = files
    export["analysis"] = {"script": file_entry(protocol_path.parents[2] / PREFIX / "verify.py", out, "analysis"),
        "outputs": outputs, "blinded": False, "blinding_key_sha256": None, "unmasked_at": None}
    export["notes"] = [{"kind": "observation", "by": "NG postrun adapter", "text":
        "One row is one arm's entire fixed finite object: 120 base/view groups and 1560 cases when complete. These groups are not independent statistical samples. Undefined and wrong defined bits remain valid measurements; positive-oracle controls are validator-only and never candidate solutions."},
        {"kind": "observation", "by": "NG postrun adapter", "text":
        "Constructor setup is charged once per group; all evaluation counters are summed. Public planning/certification twice, O(r) gate work, actual fresh recovery and validator work retain separate unweighted vectors. Global costs and CPU/RSS are not copied or prorated into 48 arm observations. Unmetered work remains disclosed. No counter replay, clock, novelty or speedup qualification."}]
    census = read(census_path)
    export["backend_record"] = {"provider_context": provider, "raw_root": str(raw), "actual_aggregate_arms": len(rows),
        "planned_arms": 48, "planned_groups": 5760, "planned_case_records": 74880,
        "compute_summary": census["compute_summary"], "global_validator_counts": (report or {}).get("validator_counts"),
        "validator_positive_controls": (report or {}).get("validator_positive_controls"),
        "group_reports": (report or {}).get("group_reports"), "actual_recovery_reports": (report or {}).get("actual_recovery_reports"),
        "parse_and_aggregation_findings": findings, "missing_raw_arms": sorted(set(mapping) - set(aggregates)),
        "native_executable_invoked": False, "candidate_counter_execution_replayed": False,
        "independent_statistical_samples": 0, "all_clocks_wall_valid": False, "scientific_validity": "not_assessed"}
    return export


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", type=Path, default=Path("/workspace/classical-ecdlp-validation-ready"))
    parser.add_argument("--collected", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--export-id", required=True)
    args = parser.parse_args()
    repo, out = args.repo_root.resolve(), args.out.resolve()
    need(not out.exists(), "fresh postrun output directory required")
    source = repo / PREFIX
    for name, digest in PINS.items():
        need(not (source / name).is_symlink() and sha(source / name) == digest, "frozen source differs: " + name)
    protocol_path = repo / "experiments/EXP-ECDLP-c45dd8/protocol.json"
    need(sha(protocol_path) == OFFICIAL_FILE_SHA and sha(source / "screen-plan.json") == PLAN_SHA
         and sha(source / "source-manifest.json") == MANIFEST_SHA, "source/plan/protocol bytes differ")
    protocol = read(protocol_path)
    need(protocol["freeze"]["protocol_sha256"] == OFFICIAL_SHA and
         hashlib.sha256(canonical({k:v for k,v in protocol.items() if k != "freeze"}).encode()).hexdigest() == OFFICIAL_SHA,
         "official protocol frozen body differs")
    sys.path.insert(0, str(repo / "tools"))
    import experiment_protocol as ep
    need(not (ep.schema_errors(protocol, "experiment.protocol/v1") or ep.lint_protocol(protocol, protocol_path.parent)), "invalid official protocol")
    raw = locate_raw(args.collected)
    tree, modal = raw.parent, raw.parent.parent.parent
    need(not out.is_relative_to(tree), "postrun outputs must be outside sealed collection")
    seal = read(tree / "output-manifest.json")
    cleanup = tree / "process-cleanup.json"
    need(seal.get("schema") == "classical.ecdlp.endpoint-reuse.modal-output-manifest/v1" and
         seal.get("study_uid1000_quiescent") is True and seal.get("process_cleanup_sha256") == sha(cleanup)
         and read(cleanup).get("quiescent") is True, "actual sealed process-quiescence evidence required")
    sealed_files, seen = [tree / "output-manifest.json"], set()
    for item in seal["files"]:
        p = member(tree, item["path"])
        need(item["path"] not in seen and p.is_file() and p.stat().st_size == item["bytes"] and sha(p) == item["sha256"], "sealed member missing/changed")
        seen.add(item["path"]); sealed_files.append(p)
    for name, digest in (("protocol.json", OFFICIAL_FILE_SHA), ("compute-plan.json", PLAN_SHA), ("source-manifest.json", MANIFEST_SHA)):
        need(sha(modal / name) == digest, "actual launch file differs: " + name)
    for name, digest in PINS.items():
        need(sha(modal / "staged-source" / name) == digest, "actually staged source differs: " + name)
    provider = read(modal / "provider-context.json")
    need(provider.get("schema") == "classical.ecdlp.nongeneric-screen.modal-provider-context/v1" and
         provider.get("backend") == "modal" and provider.get("runtime") == "vm" and provider.get("block_network") is True,
         "actual NG Modal VM context required")
    for key, prefix in (("app_id", "ap-"), ("image_id", "im-"), ("sandbox_id", "sb-")):
        need(str(provider.get(key)).startswith(prefix), "actual Modal object ID required")
    need(provider.get("source_revision_c") == SOURCE_C and provider.get("protocol_sha256") == OFFICIAL_SHA
         and provider.get("source_manifest_sha256") == MANIFEST_SHA and provider.get("compute_plan_sha256") == PLAN_SHA,
         "actual provider/source/protocol closure differs")
    out.mkdir(parents=True)  # Must exist before any export file-path validation.
    verification = out / "verification"; verification.mkdir()
    report_path = verification / "report.json"
    records_path, recovery_path = raw / "records.jsonl", raw / "recovery.jsonl"
    verdict = invoke("verify", [sys.executable, str(source / "verify.py"), str(records_path),
        "--recoveries", str(recovery_path), "--protocol", str(modal / "compute-plan.json"), "--output", str(report_path)], out, repo)
    report = read(report_path) if report_path.is_file() else None
    if report:
        need(report.get("schema") == "classical.ecdlp.nongeneric-screen-verification/v1" and report.get("scope") == "complete_fixed_fixture"
             and report.get("protocol_sha256") == [PLAN_SHA] and report.get("source_fingerprint") == [MANIFEST_SHA], "verifier report binding differs")
    records, case_errors = load_jsonl(records_path)
    recoveries, recovery_errors = load_jsonl(recovery_path)
    mapping = protocol["extensions"]["nongeneric_screen"]["raw_to_protocol_arm_id"]
    aggregates, aggregation_findings = aggregate_cases(records, recoveries, mapping)
    findings = case_errors + recovery_errors + aggregation_findings
    summary_path = raw / "compute-summary.json"
    summary = read(summary_path) if summary_path.is_file() else None
    if summary:
        need(summary.get("source_fingerprint") == MANIFEST_SHA and summary.get("protocol_sha256") == PLAN_SHA
             and summary["provider_context"]["sha256"] == sha(modal / "provider-context.json")
             and summary["provider_context"]["record"] == provider, "compute summary source/provider closure differs")
        need(summary["records_sha256"] == sha(records_path) and summary["recovery_records_sha256"] == sha(recovery_path), "compute summary/raw bytes differ")
    census_path = out / "summary-census.json"
    binding_paths = [protocol_path, modal / "compute-plan.json", modal / "source-manifest.json", modal / "provider-context.json", tree / "output-manifest.json"]
    binding_paths += [p for p in (records_path, recovery_path, summary_path, report_path) if p.is_file()]
    write(census_path, {"schema": "classical.ecdlp.nongeneric-screen.summary-census/v1", "experiment_id": "EXP-ECDLP-c45dd8",
        "run_id": "RUN-ECDLP-a11661", "measurement_started": bool(records), "protocol_sha256": OFFICIAL_SHA,
        "screen_plan_sha256": PLAN_SHA, "source_fingerprint": MANIFEST_SHA,
        "verification_report_sha256": sha(report_path) if report_path.is_file() else None,
        "input_bindings": {str(p): sha(p) for p in binding_paths}, "compute_summary": summary,
        "observed_record_count": len(records), "observed_recovery_group_records": len(recoveries),
        "operational_status": "completed" if summary and summary.get("completed") is True else "partial_or_failed",
        "parse_and_aggregation_findings": findings, "verifier_returncode": verdict["returncode"],
        "candidate_evaluations_by_postrun": 0, "positive_oracle_is_validator_only": True,
        "all_clocks_wall_valid": False, "candidate_counter_execution_replayed": False})
    export = build_export(ep, protocol, protocol_path, raw, modal, out, args.export_id, report_path, census_path,
                          aggregates, report, provider, sealed_files, findings)
    export_path = out / "export.json"
    validation = ep.schema_errors(export, "experiment.export/v1") or ep.lint_export(export, protocol, out, True)
    write(export_path, export)
    write(out / "export.json.validation.json", {"findings": validation, "actual_arm_rows": len(export["runs"]),
        "raw_case_records": len(records), "raw_recovery_group_records": len(recoveries), "planned_groups_not_independent_samples": True})
    checked = invoke("check-export", [sys.executable, str(repo / "tools/experiment_protocol.py"), "check-export", str(export_path),
        "--protocol", str(protocol_path), "--verify-files"], out, repo)
    passed = verdict["returncode"] == 0 and not findings and not validation and checked["returncode"] == 0
    write(out / "postrun-result.json", {"schema": "classical.ecdlp.nongeneric-screen.postrun/v1", "operational_pipeline_status": "completed" if passed else "findings_or_failure",
        "verifier_returncode": verdict["returncode"], "standard_check_export_returncode": checked["returncode"],
        "export_findings": validation, "export_sha256": sha(export_path), "scientific_validity": "not_assessed",
        "candidate_evaluations_by_postrun": 0, "automatic_retry": False, "all_clocks_wall_valid": False})
    print(canonical({"out": str(out), "pipeline_passed": passed, "actual_arm_rows": len(export["runs"]),
        "case_records": len(records), "recovery_group_records": len(recoveries), "scientific_validity": "not_assessed"}))
    return 0 if passed else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError, OSError, KeyError, TypeError) as error:
        print(canonical({"status": "postrun_refused_or_failed", "error_type": type(error).__name__, "error": str(error)}), file=sys.stderr)
        raise SystemExit(2)
