import CryptoResearch.Smoke
