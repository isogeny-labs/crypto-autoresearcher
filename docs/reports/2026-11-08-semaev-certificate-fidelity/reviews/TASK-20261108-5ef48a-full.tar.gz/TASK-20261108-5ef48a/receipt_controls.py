#!/usr/bin/env python3
"""Replay inexpensive receipt controls; never invokes Lean."""
from pathlib import Path
import sys
import json
import copy
import os
import subprocess

out = Path(__file__).resolve().parent
snap = out / 'snapshot'
# The snapshot has no independent Git repository. Set its worktree explicitly
# so archived_verifier_inputs resolves repository-relative pathspecs correctly.
os.environ['GIT_DIR'] = subprocess.check_output(
    ['git', 'rev-parse', '--absolute-git-dir'], cwd=out, text=True).strip()
os.environ['GIT_WORK_TREE'] = str(snap)
sys.dont_write_bytecode = True
sys.path.insert(0, str(snap))
from orchestration.formal.receipts import receipt_errors
from orchestration.formal.targets import load_spec, task_from_spec
from orchestration.formal.lean_worker import target_audit_source, scan_forbidden_text

spec = snap / 'formal/targets/semaev-decomposition-certificate.yaml'
task = task_from_spec(load_spec(spec))
receipt = json.loads((out / 'raw/semaev-decomposition-certificate.json').read_text())
rev = receipt['provenance']['source_commit']

def check(r):
    return receipt_errors(r, repo=snap, spec=spec, task=task, verifier_revision=rev)

base = check(receipt)
tests = []

def attack(name, change, expected):
    r = copy.deepcopy(receipt)
    change(r)
    errors = check(r)
    tests.append({'name': name, 'expected_error': expected,
                  'errors': errors, 'rejected': expected in errors})

attack('wrong_result_theorem', lambda r: r['verification'].update(theorem_name='CryptoResearch.Semaev.missing'), 'result identity')
attack('wrong_named_audit', lambda r: r.update(audit_log=r['audit_log'].replace('target axiom audit passed: ' + task.theorem_name, 'target axiom audit passed: ' + task.theorem_name + '_WRONG')), 'named audit log')
attack('stale_declared_source_hash', lambda r: r['provenance'].update(declared_source_sha256='0' * 64), 'declared source hash')
attack('stale_theorem_hash', lambda r: r['provenance'].update(theorem_sha256='0' * 64), 'theorem hash')
attack('unapproved_axiom_diagnostic', lambda r: r.update(audit_log=r['audit_log'] + '\nerror: target axiom audit failed: [sorryAx]\n'), 'negative audit diagnostics')
attack('forbidden_construct_recorded', lambda r: r['verification'].update(forbidden_constructs=['custom_axiom:fixture']), 'forbidden constructs')
attack('empty_build_log', lambda r: r.update(build_log=''), 'build log')
attack('empty_audit_log', lambda r: r.update(audit_log=''), 'named audit log')
attack('zero_project_theorems', lambda r: r.update(audit_log=r['audit_log'].replace('1313 theorem(s)', '0 theorem(s)')), 'nonempty project audit')
attack('missing_workspace_inputs', lambda r: r['provenance'].update(workspace_inputs={}), 'local source inputs')
attack('missing_verifier_inputs', lambda r: r['provenance'].update(verifier_inputs={}), 'verifier inputs')
attack('wrong_lean_version', lambda r: r['provenance'].update(lean_version='Lean (version 4.35.0-rc1, release)'), 'Lean version')
attack('wrong_archived_revision', lambda r: r['provenance'].update(source_commit='0' * 40), 'archived verifier revision')

# This explicitly labeled in-memory construction is a boundary control.
# Correct hashes and syntactically consistent invented logs cannot authenticate a run.
fabricated = copy.deepcopy(receipt)
fabricated['build_log'] = 'Synthetic control: no process was executed.'
fabricated['audit_log'] = 'axiom audit: 1 theorem(s), all standard axioms only\ntarget axiom audit passed: ' + task.theorem_name + '\n'
fabricated_errors = check(fabricated)
result = {
    'schema': 'semaev-receipt-controls/v1',
    'scope': 'Fresh Python receipt-consistency controls only; no Lean invocation or theorem proof',
    'baseline_errors': base,
    'controls': tests,
    'rejection_controls_all_pass': not base and all(t['rejected'] for t in tests),
    'fabricated_consistent_log_control': {
        'errors': fabricated_errors,
        'accepted': not fabricated_errors,
        'expected': 'accepted: consistency parser does not authenticate execution',
    },
    'audit_generator_source': target_audit_source('CryptoResearch.Semaev.Certificate', task.theorem_name),
    'static_target_forbidden_scan': list(scan_forbidden_text((snap / 'formal/CryptoResearch/Semaev/Certificate.lean').read_text())),
}
with (out / 'receipt-controls-with-git-context.json').open('x') as handle:
    json.dump(result, handle, indent=2)
    handle.write('\n')
print(json.dumps({k: result[k] for k in ['baseline_errors', 'rejection_controls_all_pass', 'fabricated_consistent_log_control', 'static_target_forbidden_scan']}))
assert result['rejection_controls_all_pass']
